// Sekou Hera

package com.example.ex16_21;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.File;

public class Exercise16_21 extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {

        String URL = "https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3";

        TextField textField = new TextField("0");
        textField.setFont(Font.font(50));
        textField.setPrefColumnCount(3);
        textField.setAlignment(Pos.CENTER);
        textField.setFocusTraversable(false);
        Pane pane = new Pane(textField);
        StackPane stackPane = new StackPane(pane);

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(30), e-> {
                    textField.setText((Integer.parseInt(textField.getText()) - 1) + "");
                }));

                    textField.setOnAction(e-> {
                    if (timeline.getStatus() == Animation.Status.RUNNING) {
                    timeline.stop();
            }
                    timeline.setCycleCount(Integer.parseInt(textField.getText()));
                    textField.setEditable(false);
                    timeline.play();
        });

        File file = new File(URL);
        MediaPlayer mediaPlayer = new MediaPlayer(new Media(file.toURI().toString()));

        timeline.setOnFinished(event -> {
            mediaPlayer.play();
        });
        primaryStage.setScene(new Scene(stackPane));
        primaryStage.setTitle("Exercise16_21");
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}