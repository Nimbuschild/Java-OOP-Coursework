
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

public class Exercise31_17 extends Application {
  // Text field for receiving radius
  private TextField tfAnnualInterestRate = new TextField();
  private TextField tfNumOfYears = new TextField();
  private TextField tfInvestmentAmount = new TextField();
  private TextField tfFutureValue = new TextField();
  private Button btSubmit= new Button("Submit");


  // Text area to display contents
  private TextArea ta = new TextArea();
  
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {

    MenuBar menuBar = new MenuBar();
    Pane pane = new Pane();
    pane.getChildren().add(menuBar);
    Menu menuOperation = new Menu("Operation");
    Menu menuExit = new Menu("Exit");
    menuBar.getMenus().addAll(menuOperation, menuExit);

    GridPane gridPane = new GridPane();
    gridPane.add(new Label("Annual Interest Rate"), 0, 0);
    gridPane.add(new Label("Number Of Years"), 0, 1);
    gridPane.add(new Label("Investment Amount"), 0, 2);
    gridPane.add(tfAnnualInterestRate, 1, 0);
    gridPane.add(tfNumOfYears, 1, 1);
    gridPane.add(tfInvestmentAmount, 1, 2);
    gridPane.add(btSubmit, 2, 1);
    
    tfAnnualInterestRate.setAlignment(Pos.BASELINE_RIGHT);
    tfNumOfYears.setAlignment(Pos.BASELINE_RIGHT);
    tfInvestmentAmount.setAlignment(Pos.BASELINE_RIGHT);
    
    tfInvestmentAmount.setPrefColumnCount(5);
    tfNumOfYears.setPrefColumnCount(5);
    tfInvestmentAmount.setPrefColumnCount(5);
            
    BorderPane bpane = new BorderPane();
    bpane.setCenter(new ScrollPane(ta));
    bpane.setTop(gridPane);
    
    // Create a scene and place it in the stage
    Scene scene = new Scene(bpane, 400, 250);
    primaryStage.setTitle("Exercise31_17"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    btSubmit.setOnAction(e -> futureValue());
  }

  private void futureValue() {
    double investmentAmount = Double.parseDouble(tfInvestmentAmount.getText());
    int years = Integer.parseInt(tfNumOfYears.getText());
    double monthlyInterestRate = Double.parseDouble(tfAnnualInterestRate.getText()) / 1200;
            tfFutureValue.setText(String.format("$%.2f",
            (investmentAmount * Math.pow(1 + monthlyInterestRate, years * 12))));
  }

  
  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
