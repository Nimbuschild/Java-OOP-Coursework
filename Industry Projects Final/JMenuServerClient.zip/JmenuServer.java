package com.example.demo5;
import java.io.*;
import java.lang.ClassNotFoundException;
import java.net.ServerSocket;
import java.net.Socket;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class JmenuServer extends Application {
  // Text area for displaying contents
  private TextArea ta = new TextArea();

  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    ta.setWrapText(true);

    // Create a scene and place it in the stage
    Scene scene = new Scene(new ScrollPane(ta), 400, 200);
    primaryStage.setTitle("Exercise31_01Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }
  private Socket socket = null;
  private ServerSocket server = null;
  private DataInputStream in = null;

  public JmenuServer(int port)
  {
    try
    {
      server = new ServerSocket(port);
      System.out.println("Server started");

      System.out.println("Waiting for a client ...");

      socket = server.accept();
      System.out.println("Client accepted");

      in = new DataInputStream(
              new BufferedInputStream(socket.getInputStream()));

      String line = "";

      while (!line.equals("Over"))
      {
        try
        {
          line = in.readUTF();
          System.out.println(line);

        }
        catch(IOException i)
        {
          System.out.println(i);
        }
      }
      System.out.println("Closing connection");

      socket.close();
      in.close();
    }
    catch(IOException i)
    {
      System.out.println(i);
    }
  }

  public static void main(String[] args)  {
    launch(args);

    JmenuServer server = new JmenuServer(5000);


  }
}
